// ./server/config.js
module.exports = {
  'secret': 'applicationsecret'
}
